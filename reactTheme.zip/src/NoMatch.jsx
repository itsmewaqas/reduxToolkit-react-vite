import React, { useState } from 'react';

function NoMatch() {

    return (
        <div>
            <p>There's nothing here: 404!</p>
        </div>
    );
}

export default NoMatch;