import { useState, useEffect } from 'react'
import { Container, Row, Col, Button, Form } from 'react-bootstrap';

function Login() {

  const initalState = {
    username: '',
    password: '',
  };

  const [values, setValues] = useState(initalState);
  const [errors, setErrors] = useState({});
  const [formState, setFormState] = useState([])

  const handleChnage = e => {
    const { name, value } = e.target;
    e.preventDefault();
    setValues({
      ...values,
      [name]: value
    })
  }

  // const handleSignin = e => {
  //   e.preventDefault();
  //   setErrors(validateInfo({ values }))
  //   if (values.email != '' &&
  //     values.password != '') {
  //     formState.push(values)
  //     if (formState) {
  //       setFormState(formState)
  //       navigate('/Insight');
  //       dispatch(languageSelect(languageSle));
  //       console.log(formState);
  //     }
  //   }
  // }

  useEffect(() => {
  }, [])

  return (
    <div>
      <Container fluid>
        <Row>
          <h1>Login</h1>
          <Col md={4} className='mt-5 my-5 px-5'>
            <Form.Group className="mb-3">
              <Form.Label>Username</Form.Label>
              <Form.Control type="text" name="username" placeholder="name@example.com" onChange={handleChnage} />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" name="password" placeholder="***********" onChange={handleChnage} />
            </Form.Group>
            <Button variant="success" className='mt-1'>Login</Button>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default Login
