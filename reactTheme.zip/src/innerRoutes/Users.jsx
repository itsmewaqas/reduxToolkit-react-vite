import { useState } from 'react'

function Users() {
  const [count, setCount] = useState(0)

  return (
    <div>
     Users
    </div>
  )
}

export default Users
