import { useState } from 'react'

function Profile() {
  const [count, setCount] = useState(0)

  return (
    <div>
     Profile
    </div>
  )
}

export default Profile
