import { useState } from 'react'

function Component() {
  const [count, setCount] = useState(0)

  return (
    <div>
     Component
    </div>
  )
}

export default Component
